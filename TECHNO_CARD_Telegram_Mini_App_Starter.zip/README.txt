TECHNO CARD Telegram Mini App — Starter

Files:
- index.html: responsive Arabic RTL black/orange mini-app starter.

Important:
- This is a front-end demo. It does not process payments, fulfill top-ups, or store orders.
- Telegram Web Apps API is included. Product buttons send data to the bot only when opened inside Telegram; the bot must be programmed to receive and validate it.
- To use with BotFather, publish index.html on HTTPS hosting and provide the resulting URL as the Web App URL.
- Keep this file as the base version; do not put private API keys in frontend code.
